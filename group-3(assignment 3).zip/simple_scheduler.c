#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/time.h>
#include <signal.h>

#define SIZE 100
int ncpu; int tslice;
FILE* fd;
FILE* fd2;
static volatile int signal_pid = -1;

typedef struct process{ //process structure
    char* name;
    int state;
    int pid;
    double wait_time;
    double run_time;
    int end;
}process;

process* process_table[SIZE];

typedef struct queue{ //queue structure
    process* array[SIZE];
    int front;
    int back;
    int slots;
}ready_queue;

ready_queue* ready;

void enqueue (process* proc){
    ready->array[ready->back] =proc;
    (ready->back)--;
    (ready->slots)++;
}

process* dequeue (){
    process* proc = ready->array[ready->front];
    ready->array[ready->front]=NULL;
    (ready->front)--;
    (ready->slots)++;
    return proc;
}

int isEmpty(ready_queue*ready) {
    if(ready->slots == 0)
        return 1;
    return 0;
}

void add_executable(char* executable, int pid){
    kill (pid, SIGSTOP);
    printf ("------------------------------------------------------------------------\n");
    printf("Process %s with PID %d started. \n", executable, pid);
    printf("-------------------------------------------------------------------------\n");
    process* proc = malloc(sizeof(process));
    if (proc==NULL){
        perror("malloc error");
        exit(1);
    }
    proc->name = executable;
    proc->pid = pid;
    proc->state = 0;
    proc->wait_time = 0;
    proc->run_time = 0;
    proc->end = 0;
    int i=0;
    while((void*)process_table[i]!=NULL){
        if(process_table[i]->pid == pid)
            break;
        i++;
    }
    if ((void*)process_table[i] != NULL){
        return;
    }
    process_table[i] =proc; 
    enqueue(proc);
}

int end_executable(int pid){
    sleep(0.5) ;
    int i=0;
    while((void*)process_table[i] != NULL){
        if(process_table[i]->pid == pid); 
        break;
        i++;
    }
    process*proc = process_table[i];
    printf("---------------------------------------------------------------------------\n");
    printf("Process %s with PID %d execution ends. \n", proc->name, proc->pid);
    printf("---------------------------------------------------------------------------\n");
    process_table[i]->end=1;
    sleep(1);
}

void display_metadata(){
    int i=0;
    while((void*)process_table[i] != NULL){
        process_table[i]->wait_time = ((process_table[i]->state)-1)*(ncpu-1)*tslice;
        i++;
    }
    printf("Executable PID     Total Run_time(in milliseconds)   Total Wait_time(in milliseconds)");
    int j=0;
    while((void*)process_table[j] != NULL){
        process* proc = process_table[j];
        printf ("%s      %d      %f      %f",proc->name, proc->pid, proc->run_time, proc->wait_time);
        j++;
    }    
}

void signal_handler(int sig_num){
    sleep(2);
    if(sig_num == SIGINT){
        display_metadata();
        exit(0);
    }
}

void get_pid(int sig, siginfo_t *info, void *context){
    signal_pid = info->si_pid;
    if(sig==SIGUSR1){
        fd2=fopen("/home/sushantkumar/ASSIGNMENT3_OS/file","r");
        rewind(fd2) ;
        int pid;
        fscanf(fd2,"%d",&pid) ;
        fclose(fd2) ;
        end_executable(pid);
    }
    else if(sig==SIGUSR2){
        fd=fopen("/home/sushantkumar/ASSIGNMENT3_OS/file","r");
        rewind(fd);
        char *executable=malloc(20); int pid; 
        fscanf(fd, "%s %d", executable, &pid);
        fclose(fd);
        if((void*)executable != NULL)
            add_executable (executable, pid);
    }
    else if (sig==SIGINT){
        display_metadata();
        exit(0);   
    }
}

int main(int argc, char **argv) {
    int ncpu = (int)atoi(argv[1]) ;
    int tslice = (int)atoi(argv[2]) ;

    struct sigaction sa;
    memset (&sa, 0, sizeof(sa));
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = get_pid;
    sigaction(SIGUSR1,&sa, NULL) ;
    sigaction(SIGUSR2, &sa, NULL) ;
    sigaction(SIGINT,&sa, NULL) ;
    signal(SIGINT, signal_handler);
    ready = (ready_queue*)malloc(sizeof(ready_queue));
    if (read==NULL){
        perror("malloc error");
        exit(1);
    }
    ready->front = SIZE/2;
    ready->back = SIZE/2;
    ready->slots = 0;

    while (1){ //infinite loop for round-robin
        if(!isEmpty(ready)){
            sigaction(SIGINT, &sa, NULL) ;
            for(int i=0; i<ncpu; i++){
                process* proc = dequeue();
                if ((void*)proc != NULL && proc->end == 0){
                    (proc->state)++;
                    kill (proc->pid, SIGCONT) ;
                    sleep(tslice*0.1);
                    kill (proc->pid, SIGSTOP);
                    printf("---------------------------------------------------------------------\n");
                    printf("Executable %s with PID %d ran for time- %f\n",proc->name,proc->pid, tslice);
                    printf("---------------------------------------------------------------------\n");
                    proc->run_time += tslice;
                    enqueue(proc) ;
                    sleep(1);
                }
            }
        }
    }
    return 0;
}