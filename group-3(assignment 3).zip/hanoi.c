#include <stdio.h>
int hanoi(int n){
	if (n==1)
		return 1;
	return 2*hanoi(n-1)+1;
}
int main(int argc,char**argv){
	printf("-----------------------\n");
	printf("./hanoi output is %d",hanoi(5000));
	printf("-----------------------\n");
	return 0;
}