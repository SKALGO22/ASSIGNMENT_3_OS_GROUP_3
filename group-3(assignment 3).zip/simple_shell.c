#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/time.h>
#include <signal.h>
#include <math.h>
#define SIZE 100

int scheduler_pid;
int status;
FILE* fd;
FILE* fd2;
struct sigaction sig;

void exec_instr(char*command) {
    char executable[SIZE];
    int i = 7;
    while (command[i]!='\0'){
        executable[i-7]=command[i]; 
        i++;
    }
    executable[i-7]='\0'; 
    fd=fopen("/home/sushantkumar/ASSIGNMENT3_OS/file","w"); //opening file in writable mode
    if(fork()==0) {
        fprintf(fd, "%s %d", executable, getpid()) ;
        rewind(fd);
        fclose(fd) ;
        char sch_pid[10];
        sprintf(sch_pid, "%d", scheduler_pid);
        char*args[3]={executable,sch_pid, NULL};
        sleep(0.5);
        kill(scheduler_pid, SIGCONT);//resuming the scheduler
        kill(scheduler_pid, SIGUSR2);//adding the executable in process table
        sleep(2);
        execv(args[0],args);//running the executable
    }
    else{
        int ret=wait(NULL);
        kill(scheduler_pid, SIGSTOP);//scheduler stopped
        fd2=fopen("/home/sushantkumar/ASSIGNMENT3_OS/file2", "w");
        fprintf(fd2, "%d", ret) ;
        rewind(fd2);
        fclose(fd2);
        char sch_pid[10];
        sprintf(sch_pid, "%d", ret);
        kill(scheduler_pid, SIGCONT);
        sleep(0.2);
        kill(scheduler_pid, SIGUSR1);//process termination conveyed to scheduler
    }
}

int create_process_and_run(char* command) {
    int status = fork();
    if(status < 0){ //Error Handling
        printf("Something bad happened");
        exit(0);
    } else if (status == 0){
        exec_instr(command) ;
    } else{
        int ret;
        int pid = wait(&ret); // waiting for the child process
    }
    return 1;
}

int launch(char * command) {
    int status;
    status = create_process_and_run(command);
    return status;
}

char * read_user_input(void){
    int c, k = 0;
    static char command[SIZE];
    while((c = getchar())!= '\n'){
        command[k] = c;
        k++;
    }
    command[k] = '\0';
    return command;
}

static void my_handler(int sig_num) {
    if(sig_num==SIGINT) {//catching signal Ctrl+C
        kill(scheduler_pid, SIGINT) ;
        sleep(5);
        exit(0);
    }
}

void shell_loop(){
    do{
        printf("sushantkumar@iiitd:~ ");
        char* command = read_user_input();
        status = launch(command);
        sigaction(SIGINT, &sig, NULL);
    }while(status);
}

int main(int argc, char**argv){
    if(argc<1){//Error Handling
        perror("Segmentation fault");
        exit(1);
    }
    memset(&sig, 0, sizeof(sig));
    sig.sa_handler = my_handler;
    int sch = fork();
    if (sch < 0)//Error Handling
        printf("Scheduler initiation failed!");
    else if (sch == 0){//daemon process creation
        char* args[4]={"./simple_scheduler", argv[1], argv[2],NULL};
        execv(args[0] ,args);
    }
    else {
        kill(sch, SIGSTOP);
        printf("Scheduler daemon process created with PID %d\n",sch);
        scheduler_pid=sch;
        shell_loop();
    }
    return 0;
}