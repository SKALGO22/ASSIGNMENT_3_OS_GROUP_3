#include <stdio.h>

int main(int argc,char**argv){
	printf("-----------------------\n");
	for(int i=0; i<10; i++)
		printf("Hello World!\n");
	printf("-----------------------\n");
	return 0;
}